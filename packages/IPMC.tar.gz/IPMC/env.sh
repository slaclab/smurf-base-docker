#  This file is part of the IPMC project. It is subject to the license terms in
#  the LICENSE.txt file found in the top-level directory of this distribution
#  and at https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html. No
#  part of the IPMC project, including this file, may be copied, modified,
#  propagated, or distributed except according to the terms contained in the
#  LICENSE.txt file.

# Bash environment setup for using the IPMC command wrappers
#
# This file is meant to be sourced from a shell

# bash trickery to get the full path to the parent directory for a sourced file
_ipmcRoot=$(dirname "${BASH_SOURCE[${#BASH_SOURCE[@]} - 1]}")
_ipmcRoot=$(cd ${_ipmcRoot} > /dev/null 2>&1 && pwd)

if [ -z ${HOSTTYPE} ]; then
  export HOSTTYPE
fi
case ${HOSTTYPE} in
x86_64*)
  _libPath=${_ipmcRoot}/lib64
  _binPath=${_ipmcRoot}/bin/x86_64-linux-dbg
  ;;
*)
  _libPath=${_ipmcRoot}/lib
  _binPath=${_ipmcRoot}/bin/i386-linux-dbg
  ;;
esac

if [ -z ${LD_LIBRARY_PATH} ]; then
  export LD_LIBRARY_PATH=${_libPath}
else
  export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${_libPath}
fi
export PATH=${PATH}:${_binPath}

unset _binPath
unset _libPath
unset _ipmcRoot
